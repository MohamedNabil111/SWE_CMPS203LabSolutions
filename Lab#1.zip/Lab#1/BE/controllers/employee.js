const employees = [{ id: '1', name: 'Mohamed Sayed' }];

exports.getEmployees = async (req, res, next) => {
  res.status(200).json({ data: employees });
};

exports.createEmployee = async (req, res, next) => {
  try {
    const { name, id } = req.body;

    // Validate input
    if (!id || !name) {
      return res.status(400).json({ message: "Both ID and Name are required" });
    }


    // Check if ID already exists
    const existingEmployee = employees.find(emp => emp.id === id);
    if (existingEmployee) {
      return res.status(400).json({ message: "Employee with this ID already exists" });
    }

    // Add new employee
    const newEmployee = { id, name };
    employees.push(newEmployee);

    res.status(201).json({ message: "Employee created successfully", data: newEmployee });
  } catch (error) {
    console.error("Error in createEmployee:", error);
    res.status(500).json({ message: "Internal server error" });
  }
};

exports.deleteEmployee = async (req, res, next) => {
  try {
    const { id } = req.params;
    const index = employees.findIndex(emp => emp.id === id);

    if (index === -1) {
      return res.status(404).json({ message: "Employee not found" });
    }

    employees.splice(index, 1);
    res.status(200).json({ message: "Employee deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Internal server error" });
  }
};

