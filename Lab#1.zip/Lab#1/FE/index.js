function fetchEmployees() {
  fetch('http://localhost:3000/api/v1/employee')
    .then(response => response.json())
    .then(data => {
      const tableBody = document.getElementById('dataTable');
      if (!tableBody) {
        console.error("Table body element with ID 'dataTable' not found.");
        return;
      }

      tableBody.innerHTML = ''; // Clear previous data
      const list = data.data;

      list.forEach(item => {
        const row = document.createElement('tr');

        const idCell = document.createElement('td');
        idCell.textContent = item.id;
        row.appendChild(idCell);

        const nameCell = document.createElement('td');
        nameCell.textContent = item.name;
        row.appendChild(nameCell);

        const deleteCell = document.createElement('td');
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.classList.add('btn', 'btn-danger', 'btn-sm');

        deleteButton.addEventListener('click', () => deleteEmployee(item.id));

        deleteCell.appendChild(deleteButton);
        row.appendChild(deleteCell);
        tableBody.appendChild(row);
      });
    })
    .catch(error => console.error('Error fetching employees:', error));
}


// TODO
// add event listener to submit button

document.getElementById('submitButton').addEventListener('click', (event) => {
  createEmployee(); // Calls the function to create an employee
});



// TODO
// add event listener to delete button



// TODO
function createEmployee() {
  const nameInput = document.getElementById('name');
  const idInput = document.getElementById('id');

  if (!nameInput || !nameInput.value.trim()) {
    alert('Please enter a name.');
    return;
  }

  if (!idInput || !idInput.value.trim()) {
    alert('Please enter an ID.');
    return;
  }

  fetch('http://localhost:3000/api/v1/employee', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ 
      id: idInput.value.trim(), 
      name: nameInput.value.trim() 
    }),
  })
    .then(response => {
      if (!response.ok) {
        return response.json().then(err => { throw new Error(err.message); });
      }
      return response.json();
    })
    .then(() => {
      nameInput.value = '';
      idInput.value = '';
      fetchEmployees();
    })
    .catch(error => {
      console.error('Error creating employee:', error);
      alert(error.message || 'Failed to add employee.');
    });
}

// TODO
function deleteEmployee(id) {
  fetch(`http://localhost:3000/api/v1/employee/${id}`, {
    method: 'DELETE',
  })
    .then(response => {
      if (!response.ok) {
        throw new Error(`Failed to delete employee with ID ${id}`);
      }
      return response.json();
    })
    .then(() => {
      fetchEmployees(); // Refresh list
    })
    .catch(error => {
      console.error('Error deleting employee:', error);
      alert('Failed to delete employee.');
    });
}

document.addEventListener('DOMContentLoaded', fetchEmployees);
//fetchEmployees();
