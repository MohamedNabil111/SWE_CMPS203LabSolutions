/*IMPORTANT NOTES
1- you are using JS Name Casing (CamelCasing)
2- make this code as clean as possible 
3- apply all the concepts you learned during this lab (Naming, comments,  functions)
*/

class Point {
  //this constructor is used to construct the point class
  constructor(coordinateX, coordinateY) {
    this.coordinateX = coordinateX;
    this.coordinateY = coordinateY;
  }
}

class Rectangle {
  constructor(startingPoint, width, height) {
    if (height <= 0 || width <= 0) {
      throw Error("invalid Width or Height"); // throws an error in case of width or height <= 0
    }
    this.startingPoint = startingPoint;
    this.width = width;
    this.height = height;
  }

  // ***************
  // METHODS
  // ***************

  CalculateArea() {
    return this.width * this.height;
  }

  CalculatePerimeter() {
    return 2 * (this.width + this.height);
  }

  UpdateHeight(height) {
    if (height > 0) {
      this.height = height;
      this.width = height;
    }
    //TODO: handle case of updating the height of square
  }

  update(startingPoint, width, height) {
    if (height <= 0 || width <= 0) {
      throw Error("invalid Width and Height"); // throws an error in case of width or height <= 0
    }
    this.startingPoint = startingPoint;
    this.width = width;
    this.height = height;
  }

  GetHeight() {
    return this.height;
  }

  //function that print the endpoints
  PrintEndPoints() {
    const topRightX = this.startingPoint.coordinateX + (this.width)/2;
    const topRightY = this.startingPoint.coordinateY + (this.height)/2;

    const topLeftX = this.startingPoint.coordinateX - (this.width)/2;
    const topLeftY = this.startingPoint.coordinateY + (this.height)/2;

    const bottomRightX = this.startingPoint.coordinateX + (this.width)/2;
    const bottomRightY = this.startingPoint.coordinateY - (this.height)/2;

    const bottomLeftX = this.startingPoint.coordinateX - (this.width)/2;
    const bottomLeftY = this.startingPoint.coordinateY - (this.height)/2;

    console.log("End Point Top Right: (" + topRightX + ", " + topRightY + ")");
    console.log("End Point Top Left: (" + topLeftX + ", " + topLeftY + ")");
    console.log("End Point Bottom Right: (" + bottomRightX + ", " + bottomRightY + ")");
    console.log("End Point Bottom Left: (" + bottomLeftX + ", " + bottomLeftY + ")");
    
  }

  GetWidth() {
    return this.width;
  }
}

function BuildRectangle(Width, Height, x, y) {
  const mainPoint = new Point(x, y);
  const rect = new Rectangle(mainPoint, Width, Height);
  return rect;
}

function BuildSquare(coordinateX, coordinateY, SquareHeight) {
  let square;
  if (SquareHeight <= 0) {
    throw new Error("Invalid side length for square.");
  }
  square = BuildRectangle(SquareHeight, SquareHeight, coordinateX, coordinateY);
  return square;
  // const SquareArea = square.CalculateArea();
  // const SquarePerimeter = square.CalculatePerimeter();
  // console.log("square Area ", SquareArea);
  // console.log("square Perimeter ", SquarePerimeter);
}

const MyRectangle = BuildRectangle(2, 5, 3, 4);
const MySquare = BuildSquare(3, 6, 4);

console.log("The square perimeter is " + MySquare.CalculatePerimeter() + " and the area is " + MySquare.CalculateArea());
MySquare.PrintEndPoints();

MyRectangle.UpdateHeight(3);

console.log("The rectangle perimeter is " + MyRectangle.CalculatePerimeter() + " and the area is " + MyRectangle.CalculateArea());
MyRectangle.PrintEndPoints();
