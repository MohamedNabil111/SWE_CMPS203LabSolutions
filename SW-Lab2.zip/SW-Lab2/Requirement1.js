// Inventory Data Structures
const inventory = [];
const transactions = [];
const categories = new Set();
const customFields = {};

// Add Item to Inventory
function addItem(name, category, quantity, price, unit, customFields = {}) {
    const item = {
        name, category, quantity, price, unit, addedAt: new Date(), customFields
    };
    inventory.push(item);
    categories.add(category);
    transactions.push({ type: "add", item });

    checkLowStock(item); // Check for low-stock alerts
    displayDashboard();
}

// Edit an Existing Item
function editItem(index, newName, newCategory, newQuantity, newPrice, newUnit, newCustomFields = {}) {
    if (!inventory[index]) return console.log("Error: Item not found!");

    transactions.push({ type: "edit", old: { ...inventory[index] }, new: { newName, newCategory, newQuantity, newPrice, newUnit, newCustomFields } });

    inventory[index] = { ...inventory[index], name: newName, category: newCategory, quantity: newQuantity, price: newPrice, unit: newUnit, customFields: newCustomFields };

    checkLowStock(inventory[index]);
}

// Remove an Item
function removeItem(index) {
    if (!inventory[index]) return console.log("Error: Item not found!");

    const removedItem = inventory.splice(index, 1)[0];
    transactions.push({ type: "delete", item: removedItem });

    console.log(`Item "${removedItem.name}" removed from inventory.`);
}

// Process Sale
function processSale(itemName, quantitySold) {
    const item = inventory.find(i => i.name === itemName);
    if (!item || item.quantity < quantitySold) return console.log("Error: Not enough stock!");

    item.quantity -= quantitySold;
    transactions.push({ type: "sale", item, quantitySold, date: new Date() });

    console.log(`Sold ${quantitySold} ${item.unit} of ${item.name}`);
    checkLowStock(item);
}

// Restock an Item
function restockItem(itemName, quantityAdded) {
    const item = inventory.find(i => i.name === itemName);
    if (!item) return console.log("Error: Item not found!");

    item.quantity += quantityAdded;
    transactions.push({ type: "restock", item, quantityAdded, date: new Date() });

    console.log(`Restocked ${quantityAdded} ${item.unit} of ${item.name}`);
}

// Search Items
function searchItems(query) {
    const results = inventory.filter(x =>
        [x.name, x.category, x.price].some(value =>
            value.toString().toLowerCase().includes(query.toLowerCase())
        )
    );

    console.log("Search Results:");
    results.forEach(item => console.log(formatItem(item)));
}

// View Inventory
function viewInventory() {
    console.log("=== Inventory ===");
    inventory.forEach(item => console.log(formatItem(item)));
}

// Export Inventory as CSV
function exportInventory() {
    const csv = [
        "Name, Category, Quantity, Price, Unit, AddedAt",
        ...inventory.map(item => `${item.name}, ${item.category}, ${item.quantity}, ${item.price}, ${item.unit}, ${item.addedAt}`)
    ].join("\n");

    console.log("CSV Export:\n" + csv);
}

// View Transactions
function viewTransactions() {
    console.log("Transactions:");
    transactions.forEach(t => console.log(`${t.type.toUpperCase()} - ${t.item.name}`));
}

// Add Custom Field
function addCustomField(fieldName) {
    if (!customFields[fieldName]) customFields[fieldName] = null;
}

// Update Custom Field for an Item
function updateCustomField(itemName, fieldName, value) {
    const item = inventory.find(i => i.name === itemName);
    if (item) item.customFields[fieldName] = value;
}

// Check and Log Low Stock Alert
function checkLowStock(item) {
    if (item.quantity < 10) {
        console.log(`ALERT: Item "${item.name}" is below 10 units! Current quantity: ${item.quantity}`);
    }
}

// Display Inventory Summary
function displayDashboard() {
    const totalValue = inventory.reduce((total, item) => total + item.quantity * item.price, 0);
    console.log(`=== Dashboard ===\nItems: ${inventory.length}\nTotal Value: $${totalValue.toFixed(2)}\nCategories: ${Array.from(categories).join(", ")}`);
}

// Format Item Display
function formatItem(item) {
    return `${item.name} (${item.category}) - ${item.quantity} ${item.unit} @ $${item.price}`;
}

// Sample Run
function main() {
    console.log("Running Inventory Tests...");

    addItem("Apple", "Fruit", 10, 1.5, "kg");
    addItem("Banana", "Fruit", 5, 1, "kg");
    addItem("Orange", "Fruit", 3, 2, "kg");
    addItem("Milk", "Dairy", 5, 3, "litre");

    processSale("Apple", 2);
    restockItem("Milk", 2);

    searchItems("mil");
    viewInventory();

    exportInventory();
    viewTransactions();

    addItem("Pineapple", "Fruit", 5, 3, "kg");

    addCustomField("Origin");
    updateCustomField("Apple", "Origin", "India");
}

main();